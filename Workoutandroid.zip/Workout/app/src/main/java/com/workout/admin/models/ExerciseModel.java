package com.workout.admin.models;

public class ExerciseModel {
    private String exerciseName;
    private String steps;

    public ExerciseModel() {
        // Empty constructor required by Firestore
    }

    public ExerciseModel(String exerciseName, String steps) {
        this.exerciseName = exerciseName;
        this.steps = steps;
    }

    public String getExerciseName() {
        return exerciseName;
    }

    public void setExerciseName(String exerciseName) {
        this.exerciseName = exerciseName;
    }

    public String getSteps() {
        return steps;
    }

    public void setSteps(String steps) {
        this.steps = steps;
    }
}
