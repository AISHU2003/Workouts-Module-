package com.workout.admin.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.workout.R;
import com.workout.admin.models.ChatMessage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<ChatMessage> messageList;
    private Context context;
    private String currentUser;

    private static final int VIEW_TYPE_SENT = 1;
    private static final int VIEW_TYPE_RECEIVED = 2;

    public ChatAdapter(List<ChatMessage> messageList, Context context, String currentUser) {
        this.messageList = messageList;
        this.context = context;
        this.currentUser = currentUser;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        if (viewType == VIEW_TYPE_SENT) {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_sent, parent, false);
            return new SentMessageViewHolder(view);
        } else {
            view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_received, parent, false);
            return new ReceivedMessageViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ChatMessage message = messageList.get(position);
        long messageTime = message.getMessageTime();
        String messageText = message.getMessageText();
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy - HH:mm", Locale.getDefault());
        String formattedTime = sdf.format(new Date(messageTime));

        // Adjust gravity based on message sender
        if (holder instanceof SentMessageViewHolder) {
            ((SentMessageViewHolder) holder).sentMessageText.setText(messageText);
            ((SentMessageViewHolder) holder).sentMessageTime.setText(formattedTime);

        } else if (holder instanceof ReceivedMessageViewHolder) {
            ((ReceivedMessageViewHolder) holder).receivedMessageText.setText(messageText);
            ((ReceivedMessageViewHolder) holder).receivedMessageTime.setText(formattedTime);
            ((ReceivedMessageViewHolder) holder).receivedMessageUser.setText(message.getMessageUser());
        }
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    @Override
    public int getItemViewType(int position) {
        ChatMessage message = messageList.get(position);
        if (message.getMessageUser().equals(currentUser)) {
            return VIEW_TYPE_SENT;
        } else {
            return VIEW_TYPE_RECEIVED;
        }
    }

    static class SentMessageViewHolder extends RecyclerView.ViewHolder {
        TextView sentMessageText;
        TextView sentMessageTime;

        SentMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            sentMessageText = itemView.findViewById(R.id.text_message_body);
            sentMessageTime = itemView.findViewById(R.id.text_message_time);
        }
    }

    static class ReceivedMessageViewHolder extends RecyclerView.ViewHolder {
        TextView receivedMessageText;
        TextView receivedMessageTime;
        TextView receivedMessageUser;

        ReceivedMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            receivedMessageText = itemView.findViewById(R.id.text_message_body);
            receivedMessageTime = itemView.findViewById(R.id.text_message_time);
            receivedMessageUser = itemView.findViewById(R.id.text_message_username);
        }
    }
}
