package com.workout.model;

import com.google.firebase.firestore.PropertyName;

public class ExerciseModel {
    @PropertyName("exerciseName")
    private String exerciseName;
    @PropertyName("steps")
    private String steps;
    @PropertyName("imageUrl")
    private String imageUrl;

    // Default constructor
    public ExerciseModel() {
    }

    // Constructor with parameters
    public ExerciseModel(String exerciseName, String steps, String imageUrl) {
        this.exerciseName = exerciseName;
        this.steps = steps;
        this.imageUrl = imageUrl;
    }

    // Getters and setters
    @PropertyName("exerciseName")
    public String getExerciseName() {
        return exerciseName;
    }

    @PropertyName("exerciseName")
    public void setExerciseName(String exerciseName) {
        this.exerciseName = exerciseName;
    }

    public String getSteps() {
        return steps;
    }

    public void setSteps(String steps) {
        this.steps = steps;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
