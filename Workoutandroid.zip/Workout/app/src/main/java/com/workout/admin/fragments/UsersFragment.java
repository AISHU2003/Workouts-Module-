package com.workout.admin.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.workout.R;
import com.workout.admin.adapters.UserAdapter;
import com.workout.admin.models.User;

import java.util.ArrayList;
import java.util.List;

public class UsersFragment extends Fragment {

    private RecyclerView recyclerView;
    private UserAdapter userAdapter;
    private List<User> userList;

    public UsersFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_users, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        userList = new ArrayList<>();
        userAdapter = new UserAdapter(getContext(), userList); // Pass the fragment as onDeleteClickListener
        recyclerView.setAdapter(userAdapter);

        loadUsersFromFirestore();
    }

    private void loadUsersFromFirestore() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("users")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        userList.clear();
                        for (DocumentSnapshot document : task.getResult()) {
                            String username = document.getString("username");
                            String email = document.getString("email");
                            User user = new User(username, email);
                            userList.add(user);
                        }
                        userAdapter.notifyDataSetChanged();
                    } else {
                        Log.e("Firestore", "Error getting documents: ", task.getException());
                        Toast.makeText(getContext(), "Error loading users", Toast.LENGTH_SHORT).show();
                    }
                });
    }

//    @Override
//    public void onDeleteClick(User user) {
//        // Get the user's email
//        String email = user.getEmail();
//
//        // Delete the user document from Firestore
//        FirebaseFirestore db = FirebaseFirestore.getInstance();
//        db.collection("users")
//                .document(email)
//                .delete()
//                .addOnCompleteListener(task -> {
//                    if (task.isSuccessful()) {
//                        // User document deleted successfully, now delete user from Authentication
//                        deleteUserFromAuthentication(email);
//                    } else {
//                        Log.e("Firestore", "Error deleting user document: ", task.getException());
//                        Toast.makeText(getContext(), "Error deleting user", Toast.LENGTH_SHORT).show();
//                    }
//                });
//    }

//    private void deleteUserFromAuthentication(String email) {
//        // Delete the user from Firebase Authentication
//        FirebaseAuth.getInstance().getUserByEmail(email)
//                .addOnCompleteListener(task -> {
//                    if (task.isSuccessful()) {
//                        FirebaseUser user = task.getResult();
//                        if (user != null) {
//                            user.delete()
//                                    .addOnCompleteListener(authDeleteTask -> {
//                                        if (authDeleteTask.isSuccessful()) {
//                                            // User deleted successfully from both Firestore and Authentication
//                                            Toast.makeText(getContext(), "User deleted successfully", Toast.LENGTH_SHORT).show();
//                                        } else {
//                                            // Error deleting user from Firebase Authentication
//                                            Log.e("Authentication", "Error deleting user: ", authDeleteTask.getException());
//                                            Toast.makeText(getContext(), "Error deleting user", Toast.LENGTH_SHORT).show();
//                                        }
//                                    });
//                        } else {
//                            // User not found in Authentication
//                            Toast.makeText(getContext(), "User not found in Authentication", Toast.LENGTH_SHORT).show();
//                        }
//                    } else {
//                        // Error retrieving user by email from Authentication
//                        Log.e("Authentication", "Error retrieving user by email: ", task.getException());
//                        Toast.makeText(getContext(), "Error deleting user", Toast.LENGTH_SHORT).show();
//                    }
//                });
//    }
}
