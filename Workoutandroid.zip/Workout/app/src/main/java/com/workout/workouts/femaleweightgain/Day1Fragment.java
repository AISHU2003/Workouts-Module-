package com.workout.workouts.femaleweightgain;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.workout.ExerciseDetailActivity;
import com.workout.R;
import com.workout.adapter.ExerciseAdapter;
import com.workout.model.Exercise;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Day1Fragment extends Fragment {

    private RecyclerView recyclerView;
    private ExerciseAdapter exerciseAdapter;
    private List<Exercise> exerciseList;

    public Day1Fragment() {
        // Required empty public constructor
    }

    public static Day1Fragment newInstance() {
        return new Day1Fragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_day1, container, false);

        recyclerView = view.findViewById(R.id.recyclerView);
        exerciseList = generateExerciseList();
        exerciseAdapter = new ExerciseAdapter(exerciseList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(exerciseAdapter);

        // Set item click listener
        exerciseAdapter.setOnItemClickListener(new ExerciseAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Exercise exercise) {
                // Start ExerciseDetailActivity and pass exercise details
                Intent intent = new Intent(getContext(), ExerciseDetailActivity.class);
                intent.putExtra("exerciseName", exercise.getName());
                intent.putExtra("description", TextUtils.join("\n", exercise.getDescriptionPoints()));
                intent.putExtra("imageResourceId", exercise.getGifResource());
                startActivity(intent);
            }
        });

        return view;
    }

    private List<Exercise> generateExerciseList() {
        List<Exercise> exercises = new ArrayList<>();
        // Add exercises to the list with GIF resource IDs
        exercises.add(new Exercise("Exercise 1", Arrays.asList("Point 1", "Point 2", "Point 3"), R.drawable.gif1));
        exercises.add(new Exercise("Exercise 2", Arrays.asList("Point A", "Point B", "Point C"), R.drawable.gif2));
        // Add more exercises as needed
        return exercises;
    }

}
