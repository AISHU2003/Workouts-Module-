package com.workout.admin.models;


import android.os.Parcel;
import android.os.Parcelable;

public class ClassModel implements Parcelable{
    private String id;
    private String className;
    private String classDescription;
    private String classTime;
    private String amount;
    private String meetingURL;
    private String imageUri;

    public ClassModel() {
        // Required empty public constructor
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassDescription() {
        return classDescription;
    }

    public void setClassDescription(String classDescription) {
        this.classDescription = classDescription;
    }

    public String getClassTime() {
        return classTime;
    }

    public void setClassTime(String classTime) {
        this.classTime = classTime;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getMeetingURL() {
        return meetingURL;
    }

    public void setMeetingURL(String meetingURL) {
        this.meetingURL = meetingURL;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    // Parcelable implementation
    protected ClassModel(Parcel in) {
        id = in.readString();
        className = in.readString();
        classDescription = in.readString();
        classTime = in.readString();
        amount = in.readString();
        meetingURL = in.readString();
        imageUri = in.readString();
    }

    public static final Creator<ClassModel> CREATOR = new Creator<ClassModel>() {
        @Override
        public ClassModel createFromParcel(Parcel in) {
            return new ClassModel(in);
        }

        @Override
        public ClassModel[] newArray(int size) {
            return new ClassModel[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(className);
        dest.writeString(classDescription);
        dest.writeString(classTime);
        dest.writeString(amount);
        dest.writeString(meetingURL);
        dest.writeString(imageUri);
    }
}

