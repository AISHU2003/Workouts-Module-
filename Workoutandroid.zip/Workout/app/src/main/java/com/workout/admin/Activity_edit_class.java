package com.workout.admin;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.workout.R;
import com.workout.admin.models.ClassModel;


public class Activity_edit_class extends AppCompatActivity {

    EditText editTextClassName, editTextClassDescription, editTextClassTime, editTextAmount, editTextMeetingURL;
    Button buttonSave;
    ClassModel classModel;

    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_class);

        db = FirebaseFirestore.getInstance();

        // Initialize Views
        editTextClassName = findViewById(R.id.editTextClassName);
        editTextClassDescription = findViewById(R.id.editTextClassDescription);
        editTextClassTime = findViewById(R.id.editTextClassTime);
        editTextAmount = findViewById(R.id.editTextAmount);
        editTextMeetingURL = findViewById(R.id.editTextMeetingURL);
        buttonSave = findViewById(R.id.buttonSave);

        // Retrieve ClassModel from Intent
        classModel = getIntent().getParcelableExtra("classModel");

        // Populate EditText fields with class details
        if (classModel != null) {
            editTextClassName.setText(classModel.getClassName());
            editTextClassDescription.setText(classModel.getClassDescription());
            editTextClassTime.setText(classModel.getClassTime());
            editTextAmount.setText(classModel.getAmount());
            editTextMeetingURL.setText(classModel.getMeetingURL());
        }

        // Handle Save button click
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update class details
                updateClassDetails();
            }
        });
    }

    private void updateClassDetails() {
        // Get updated class details from EditText fields
        String updatedClassName = editTextClassName.getText().toString().trim();
        String updatedClassDescription = editTextClassDescription.getText().toString().trim();
        String updatedClassTime = editTextClassTime.getText().toString().trim();
        String updatedAmount = editTextAmount.getText().toString().trim();
        String updatedMeetingURL = editTextMeetingURL.getText().toString().trim();

        // Create a new ClassModel object with updated details
        ClassModel updatedClassModel = new ClassModel();
        updatedClassModel.setClassName(updatedClassName);
        updatedClassModel.setClassDescription(updatedClassDescription);
        updatedClassModel.setClassTime(updatedClassTime);
        updatedClassModel.setAmount(updatedAmount);
        updatedClassModel.setMeetingURL(updatedMeetingURL);

        // Log the updated class name for confirmation
        Log.d("UpdateClassDetails", "Searching for class name: " + updatedClassName);

        // Check if the document with the updated class name exists
        db.collection("classes").document(updatedClassName).get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                // Document with the updated class name exists, update it
                                updateExistingDocument(updatedClassName, updatedClassModel);
                            } else {
                                // Document with the updated class name does not exist
                                Toast.makeText(Activity_edit_class.this, "Class does not exist", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Error occurred while checking document existence
                            Toast.makeText(Activity_edit_class.this, "Error checking class existence", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void updateExistingDocument(String updatedClassName, ClassModel updatedClassModel) {
        // Remove the imageUri field from the updatedClassModel
        updatedClassModel.setImageUri(classModel.getImageUri());

        // Update document in Firestore using the updated class name
        db.collection("classes").document(updatedClassName).set(updatedClassModel)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // Update successful
                            Toast.makeText(Activity_edit_class.this, "Class details updated successfully", Toast.LENGTH_SHORT).show();
                            finish();
                        } else {
                            // Update failed
                            Toast.makeText(Activity_edit_class.this, "Failed to update class details", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }


}
