package com.workout.model;

import java.util.List;

public class Exercise {
    private String name;
    private List<String> descriptionPoints;
    private int gifResource;

    public Exercise(String name, List<String> descriptionPoints, int gifResource) {
        this.name = name;
        this.descriptionPoints = descriptionPoints;
        this.gifResource = gifResource;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getDescriptionPoints() {
        return descriptionPoints;
    }

    public void setDescriptionPoints(List<String> descriptionPoints) {
        this.descriptionPoints = descriptionPoints;
    }

    public int getGifResource() {
        return gifResource;
    }

    public void setGifResource(int gifResource) {
        this.gifResource = gifResource;
    }
}
