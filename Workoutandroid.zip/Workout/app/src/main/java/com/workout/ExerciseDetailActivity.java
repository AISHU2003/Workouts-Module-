package com.workout;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.workout.R;

public class ExerciseDetailActivity extends AppCompatActivity {
    private TextView exerciseNameTextView;
    private TextView descriptionTextView;
    private pl.droidsonroids.gif.GifImageView imageView;
    private Button startButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_detail);

        exerciseNameTextView = findViewById(R.id.exercise_name_text_view);
        descriptionTextView = findViewById(R.id.description_text_view);
        imageView = findViewById(R.id.exercise_image_view);
        startButton = findViewById(R.id.start_button);

        // Retrieve exercise details from intent extras
        String exerciseName = getIntent().getStringExtra("exerciseName");
        String description = getIntent().getStringExtra("description");
        int imageResourceId = getIntent().getIntExtra("imageResourceId", 0); // Default value

        // Set exercise details to views
        exerciseNameTextView.setText(exerciseName);
        descriptionTextView.setText(description);

        // Set GIF image resource directly
        imageView.setImageResource(imageResourceId);

        // Set click listener for start button
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle start button click
                showTimerDialog(30); // Example: Pass initial time as 30 seconds
            }
        });
    }

    private void showTimerDialog(final int initialSeconds) {
        // Create a dialog
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_timer);
        dialog.setCancelable(false); // Prevent dialog from being dismissed by tapping outside

        // Adjust dialog dimensions based on screen size
        ViewGroup.LayoutParams params = dialog.getWindow().getAttributes();
        params.width = ViewGroup.LayoutParams.MATCH_PARENT;
        params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        dialog.getWindow().setAttributes((android.view.WindowManager.LayoutParams) params);

        // Initialize views
        TextView timerTextView = dialog.findViewById(R.id.timerTextView);
        Button playButton = dialog.findViewById(R.id.playButton);
        Button pauseButton = dialog.findViewById(R.id.pauseButton);
        Button resetButton = dialog.findViewById(R.id.resetButton);
        Button closeButton = dialog.findViewById(R.id.closeButton);

        // Set initial timer value
        timerTextView.setText(String.valueOf(initialSeconds));

        // Initialize the remaining time variable
        long[] remainingTime = {initialSeconds * 1000};
        CountDownTimer[] timer = {createTimer(remainingTime[0], timerTextView)};
        boolean[] isTimerRunning = {false}; // Track if the timer is running

        // Play button click listener
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start or resume the timer
                if (!isTimerRunning[0]) {
                    timer[0] = createTimer(remainingTime[0], timerTextView);
                    timer[0].start();
                    isTimerRunning[0] = true;
                }
            }
        });

        // Pause/Resume button click listener
        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isTimerRunning[0]) {
                    // Pause the timer and store the remaining time
                    timer[0].cancel();
                    isTimerRunning[0] = false;
                    remainingTime[0] = Long.parseLong(timerTextView.getText().toString()) * 1000; // Update remaining time
                } else {
                    // Resume the timer
                    timer[0] = createTimer(remainingTime[0], timerTextView);
                    timer[0].start();
                    isTimerRunning[0] = true;
                }
            }
        });

        // Reset button click listener
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Reset the timer and set it to initial value
                remainingTime[0] = initialSeconds * 1000;
                timerTextView.setText(String.valueOf(initialSeconds));
                // Restart the timer
                timer[0].cancel();
                timer[0] = createTimer(remainingTime[0], timerTextView);
                isTimerRunning[0] = false;
            }
        });

        // Close button click listener
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Dismiss the dialog
                dialog.dismiss();
            }
        });

        // Show the dialog
        dialog.show();
    }

    // Create CountDownTimer
    private CountDownTimer createTimer(long remainingTime, TextView timerTextView) {
        return new CountDownTimer(remainingTime, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                // Update timer text
                timerTextView.setText(String.valueOf(millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                // Timer finished, handle accordingly
                timerTextView.setText("Finished");
            }
        };
    }
}
