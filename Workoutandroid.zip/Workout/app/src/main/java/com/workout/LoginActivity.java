package com.workout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.workout.login.ForgotPasswordFragment;
import com.workout.login.LoginFragment;
import com.workout.login.RegisterFragment;

public class LoginActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if (savedInstanceState == null) {
            loadLoginFragment(); // Load LoginFragment by default
        }
    }
        public void loadLoginFragment() {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.frame_layout, new LoginFragment())
                    .commit();
        }

        public void loadRegisterFragment() {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.frame_layout, new RegisterFragment())
                    .addToBackStack(null)  // This adds the transaction to the back stack
                    .commit();
        }

        public void loadForgotPasswordFragment() {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.frame_layout, new ForgotPasswordFragment())
                    .addToBackStack(null)  // This adds the transaction to the back stack
                    .commit();
        }

}