package com.workout;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.workout.adapter.ClassAdapter;
import com.workout.model.ClassModel;

import java.util.ArrayList;
import java.util.List;

public class ClassesFragment extends Fragment {

    private FirebaseFirestore db;
    private RecyclerView recyclerView;
    private ClassAdapter classAdapter;
    private List<ClassModel> classList;

    public ClassesFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Initialize Firestore
        db = FirebaseFirestore.getInstance();
        // Initialize classList
        classList = new ArrayList<>();
        // Initialize adapter
        classAdapter = new ClassAdapter(classList, getContext());
        // Load classes data from Firestore
        loadClassesData();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_classes, container, false);
        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(classAdapter);
        return view;
    }

    private void loadClassesData() {
        // Fetch data from Firestore
        db.collection("classes")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            // Clear the existing list
                            classList.clear();
                            // Add new data from Firestore
                            for (DocumentSnapshot document : task.getResult()) {
                                ClassModel classModel = document.toObject(ClassModel.class);
                                classList.add(classModel);
                            }
                            // Notify the adapter that data set has changed
                            classAdapter.notifyDataSetChanged();
                        } else {
                            // Log error if data retrieval fails
                            // You can handle this according to your app's requirements
                            // For now, I'll just log the error
                            Exception e = task.getException();
                            if (e != null) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
    }
}
