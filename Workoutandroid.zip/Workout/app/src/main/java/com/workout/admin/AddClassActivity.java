package com.workout.admin;

import com.workout.R;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AddClassActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private EditText classNameEditText;
    private EditText classDescriptionEditText;
    private EditText classTimeEditText;
    private EditText amountEditText;
    private EditText meetingURLEditText;
    private Button addImageButton;
    private ImageView imageView;
    private Button saveButton;

    private Uri imageUri;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_class);

        classNameEditText = findViewById(R.id.editTextClassName);
        classDescriptionEditText = findViewById(R.id.editTextClassDescription);
        classTimeEditText = findViewById(R.id.editTextClassTime);
        amountEditText = findViewById(R.id.editTextAmount);
        meetingURLEditText = findViewById(R.id.editTextMeetingURL);
        addImageButton = findViewById(R.id.buttonAddImage);
        imageView = findViewById(R.id.imageView);
        saveButton = findViewById(R.id.buttonSave);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference("class_images");

        addImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveClassDetails();
            }
        });
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            imageView.setImageURI(imageUri);
        }
    }

    private void saveClassDetails() {
        final String className = classNameEditText.getText().toString().trim();
        final String classDescription = classDescriptionEditText.getText().toString().trim();
        final String classTime = classTimeEditText.getText().toString().trim();
        final String amount = amountEditText.getText().toString().trim();
        final String meetingURL = meetingURLEditText.getText().toString().trim();

        if (TextUtils.isEmpty(className) || TextUtils.isEmpty(classDescription) || TextUtils.isEmpty(classTime) || TextUtils.isEmpty(amount) || TextUtils.isEmpty(meetingURL) || imageUri == null) {
            Toast.makeText(this, "Please fill in all fields and select an image", Toast.LENGTH_SHORT).show();
            return;
        }

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Saving class details...");
        progressDialog.show();

        final String imageFileName = UUID.randomUUID().toString();
        final StorageReference fileReference = storageReference.child(imageFileName);

        UploadTask uploadTask = fileReference.putFile(imageUri);
        uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
            @Override
            public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if (!task.isSuccessful()) {
                    throw task.getException();
                }

                // Continue with the task to get the download URL
                return fileReference.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Uri>() {
            @Override
            public void onComplete(@NonNull Task<Uri> task) {
                if (task.isSuccessful()) {
                    Uri downloadUri = task.getResult();

                    // Save class details to Firestore
                    Map<String, Object> classData = new HashMap<>();
                    classData.put("className", className);
                    classData.put("classDescription", classDescription);
                    classData.put("classTime", classTime);
                    classData.put("amount", amount);
                    classData.put("meetingURL", meetingURL);
                    classData.put("imageUri", downloadUri.toString());

                    // Use className as the document ID
                    db.collection("classes").document(className)
                            .set(classData)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        progressDialog.dismiss();
                                        Toast.makeText(AddClassActivity.this, "Class details saved successfully", Toast.LENGTH_SHORT).show();
                                        finish();
                                    } else {
                                        progressDialog.dismiss();
                                        Toast.makeText(AddClassActivity.this, "Failed to save class details", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
            }

        });
    }
}
