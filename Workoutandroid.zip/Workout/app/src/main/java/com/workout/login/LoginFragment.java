package com.workout.login;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.workout.MainActivity;
import com.workout.R;
import com.workout.admin.AdminActivity;

public class LoginFragment extends Fragment {

    private EditText emailEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private TextView registerTextView;
    private TextView forgotPasswordTextView;

    private FirebaseAuth mAuth;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        emailEditText = view.findViewById(R.id.editTextEmail);
        passwordEditText = view.findViewById(R.id.editTextPassword);
        loginButton = view.findViewById(R.id.buttonLogin);
        registerTextView = view.findViewById(R.id.textViewRegister);
        forgotPasswordTextView = view.findViewById(R.id.textViewForgotPassword);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser();
            }
        });

        registerTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to RegisterFragment
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.frame_layout, new RegisterFragment())
                        .addToBackStack(null)
                        .commit();
            }
        });

        forgotPasswordTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to ForgotPasswordFragment
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.frame_layout, new ForgotPasswordFragment())
                        .addToBackStack(null)
                        .commit();
            }
        });

        return view;
    }

    private void loginUser() {
        ProgressDialog progressDialog = new ProgressDialog(requireActivity());
        progressDialog.setMessage("Logging in...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Check if the email and password match the admin credentials
        if (email.equals("admin@gmail.com") && password.equals("admin")) {
            // Navigate to ActivityAdmin
            Intent adminIntent = new Intent(getActivity(), AdminActivity.class);
            startActivity(adminIntent);
            requireActivity().finish(); // Finish the current activity
            progressDialog.dismiss();
        } else {
            // If not admin credentials, proceed with regular login
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(requireActivity(), task -> {
                        progressDialog.dismiss();
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null) {
                                FirebaseFirestore db = FirebaseFirestore.getInstance();
                                DocumentReference userRef = db.collection("users").document(user.getUid());
                                userRef.get().addOnSuccessListener(documentSnapshot -> {
                                    if (documentSnapshot.exists()) {
                                        String username = documentSnapshot.getString("username");
                                        String emailuser = documentSnapshot.getString("email");
                                        Toast.makeText(getActivity(), "Welcome, " + username, Toast.LENGTH_SHORT).show();
                                        // Login success, navigate to MainActivity
                                        Intent intent = new Intent(getActivity(), MainActivity.class);
                                        intent.putExtra("username", username);
                                        intent.putExtra("useremail",emailuser);
                                        startActivity(intent);
                                        requireActivity().finish();
                                    } else {
                                        // User document doesn't exist in Firestore
                                        Toast.makeText(getActivity(), "User data not found", Toast.LENGTH_SHORT).show();
                                    }
                                }).addOnFailureListener(e -> {
                                    // Error retrieving user data from Firestore
                                    Toast.makeText(getActivity(), "Error retrieving user data", Toast.LENGTH_SHORT).show();
                                });
                            } else {
                                // Current user is null
                                Toast.makeText(getActivity(), "User not found", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Authentication failed
                            Toast.makeText(getActivity(), "Authentication failed", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }



}
