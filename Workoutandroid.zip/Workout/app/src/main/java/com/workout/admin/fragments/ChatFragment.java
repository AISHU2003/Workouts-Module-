package com.workout.admin.fragments;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.workout.R;
import com.workout.admin.adapters.ChatAdapter;
import com.workout.admin.models.ChatMessage;

import java.util.ArrayList;
import java.util.List;

public class ChatFragment extends Fragment {

    private RecyclerView recyclerView;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> messageList;
    private EditText editTextMessage;
    private Button buttonSend;

    String username;

    FirebaseAuth auth = FirebaseAuth.getInstance();
    FirebaseUser currentUser = auth.getCurrentUser();


    public ChatFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_chat, container, false);
    }

    public static ChatFragment newInstance(String username) {
        ChatFragment fragment = new ChatFragment();
        Bundle args = new Bundle();
        args.putString("username", username);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager(requireContext());
        layoutManager.setReverseLayout(true); // Reverse layout to display items from bottom to top
        recyclerView.setLayoutManager(layoutManager);

        if (getArguments() != null) {
            username = getArguments().getString("username");
        }

        messageList = new ArrayList<>();
        chatAdapter = new ChatAdapter(messageList, requireContext(), username);
        recyclerView.setAdapter(chatAdapter);

        editTextMessage = view.findViewById(R.id.edit_text_message);
        buttonSend = view.findViewById(R.id.button_send);
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });

        // Load messages from Firestore
        loadMessagesFromFirestore();

    }


    private void loadMessagesFromFirestore() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("chats")
                .orderBy("messageTime") // Order messages by time to ensure correct ordering
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("Firestore", "Listen failed.", error);
                        return;
                    }

                    messageList.clear(); // Clear existing messages
                    for (DocumentSnapshot document : value.getDocuments()) {
                        String messageText = document.getString("messageText");
                        String messageUser = document.getString("messageUser");
                        long messageTime = document.getLong("messageTime");

                        ChatMessage message = new ChatMessage(messageText, messageUser, messageTime);
                        messageList.add(0, message); // Add new message to the beginning of the list
                    }

                    chatAdapter.notifyDataSetChanged(); // Notify adapter of data change
                });
    }

    // Method to send the message
    private void sendMessage() {
        String messageText = editTextMessage.getText().toString().trim();
        if (!messageText.isEmpty()) {
            if (username == null) {
                // Show a toast indicating that the username is not available
                Toast.makeText(requireContext(), "Username not available", Toast.LENGTH_SHORT).show();
                return;
            }

            long messageTime = System.currentTimeMillis(); // Current time in milliseconds

            // Create a new ChatMessage object
            ChatMessage message = new ChatMessage(messageText, username, messageTime);

            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("chats").add(message)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            // Message added successfully to Firestore
                            editTextMessage.setText(""); // Clear the EditText after sending the message

                            Log.d("Username:", username);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Failed to add message to Firestore
                            Toast.makeText(requireContext(), "Failed to send message", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private void scrollToBottom() {
        recyclerView.scrollToPosition(messageList.size() - 1);
    }



}
