package com.workout.excercisescreens;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.workout.R;
import com.workout.workouts.femaleweightgain.Day1Fragment;

public class FemaleWeightGainFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public FemaleWeightGainFragment() {
        // Required empty public constructor
    }

    public static FemaleWeightGainFragment newInstance(String param1, String param2) {
        FemaleWeightGainFragment fragment = new FemaleWeightGainFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_female_weight_gain, container, false);
        LinearLayout dayContainer = view.findViewById(R.id.dayContainer);

        for (int i = 1; i <= 30; i++) {
            RelativeLayout relativeLayout = new RelativeLayout(getContext());
            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.MATCH_PARENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(0, 10, 0, 0); // Set margin here
            relativeLayout.setLayoutParams(layoutParams);
            relativeLayout.setBackgroundResource(R.drawable.bg_message_received);
            relativeLayout.setPadding(10, 10, 10, 10);

            TextView textView = new TextView(getContext());
            RelativeLayout.LayoutParams textParams = new RelativeLayout.LayoutParams(
                    RelativeLayout.LayoutParams.WRAP_CONTENT,
                    RelativeLayout.LayoutParams.WRAP_CONTENT);
            textView.setLayoutParams(textParams);
            textView.setText("Day " + i);
            textView.setTextSize(25);
            textView.setTextColor(getResources().getColor(R.color.black));
            textView.setPadding(10, 10, 10, 10);
            textView.setTypeface(getResources().getFont(R.font.poppins_regular));
            relativeLayout.addView(textView);

            final int dayNumber = i; // final variable to access within onClickListener

            relativeLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Navigate to different fragment based on dayNumber
                    switch (dayNumber) {
                        case 1:
                            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new Day1Fragment()).commit();
                            break;
                        case 2:
                            // Navigate to Fragment2
                            break;
                        // Add cases for other days
                        default:
                            // Handle other days
                            break;
                    }
                }
            });

            dayContainer.addView(relativeLayout);
        }
        return view;
    }
}
