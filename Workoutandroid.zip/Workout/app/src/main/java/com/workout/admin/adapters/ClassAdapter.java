package com.workout.admin.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;
import com.workout.R;
import com.workout.admin.Activity_edit_class;
import com.workout.admin.PaymentActivity;
import com.workout.admin.models.ClassModel;


import java.util.List;

public class ClassAdapter extends RecyclerView.Adapter<ClassAdapter.ViewHolder> {

    private List<ClassModel> classList;
    private Context context;
    private FirebaseFirestore db; // Declare db variable


    public ClassAdapter(List<ClassModel> classList, FirebaseFirestore db) {
        this.classList = classList;
        this.db = db;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View view = LayoutInflater.from(context).inflate(R.layout.item_class, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ClassModel classModel = classList.get(position);
        holder.textClassName.setText(classModel.getClassName());
        holder.textClassDescription.setText(classModel.getClassDescription());
        holder.textClassTime.setText(classModel.getClassTime());
        holder.textAmount.setText(classModel.getAmount());
        holder.textMeetingURL.setText(classModel.getMeetingURL());

        // Implement onClick listener for the item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to PaymentActivity
                Intent intent = new Intent(context, PaymentActivity.class);
                // Pass any necessary data to PaymentActivity using intent extras
                intent.putExtra("className", classModel.getClassName());
                // Start the activity
                context.startActivity(intent);
            }
        });


        // Load image using Picasso
        Picasso.get().load(classModel.getImageUri()).into(holder.imageView);

        // Implement onClick listeners for edit and delete buttons
        holder.buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the position of the clicked item
                int position = holder.getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    // Get the class name of the class to be edited
                    String classNameToEdit = classModel.getClassName();
                    // Get the ClassModel object at the clicked position
                    ClassModel classModel = classList.get(position);
                    // Create an Intent to start EditClassActivity
                    Intent intent = new Intent(context, Activity_edit_class.class);
                    // Pass the ClassModel object as an extra
                    intent.putExtra("classModel", classModel);
                    // Start the activity
                    context.startActivity(intent);
                }
            }
        });


        holder.buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the position of the clicked item
                int position = holder.getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    // Get the ClassModel object at the clicked position
                    ClassModel classModel = classList.get(position);
                    // Get the class name of the class to be deleted
                    String classNameToDelete = classModel.getClassName();

                    // Delete the document from Firestore
                    db.collection("classes").document(classNameToDelete)
                            .delete()
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    // Document deleted successfully
                                    // Remove the item from the RecyclerView
                                    classList.remove(position);
                                    notifyItemRemoved(position);
                                    notifyItemRangeChanged(position, classList.size());
                                    // Notify the user
                                    Toast.makeText(context, "Class deleted successfully", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // Failed to delete the document
                                    Toast.makeText(context, "Failed to delete class", Toast.LENGTH_SHORT).show();
                                }
                            });
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return classList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView textClassName;
        public TextView textClassDescription;
        public TextView textClassTime;
        public TextView textAmount;
        public TextView textMeetingURL;
        public ImageView imageView;
        public Button buttonEdit;
        public Button buttonDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textClassName = itemView.findViewById(R.id.textClassName);
            textClassDescription = itemView.findViewById(R.id.textClassDescription);
            textClassTime = itemView.findViewById(R.id.textClassTime);
            textAmount = itemView.findViewById(R.id.textAmount);
            textMeetingURL = itemView.findViewById(R.id.textMeetingURL);
            imageView = itemView.findViewById(R.id.imageView);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
