package com.workout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;

import com.workout.model.ClassModel;

public class ClassDetailActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView textClassName;
    private TextView textClassDescription;
    private TextView textClassTime;
    private TextView textAmount;
    private TextView textMeetingURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_detail);

        // Initialize views
        imageView = findViewById(R.id.imageView);
        textClassName = findViewById(R.id.textClassName);
        textClassDescription = findViewById(R.id.textClassDescription);
        textClassTime = findViewById(R.id.textClassTime);
        textAmount = findViewById(R.id.textAmount);
        textMeetingURL = findViewById(R.id.textMeetingURL);

        // Get the class model data from the Intent
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("classModel")) {
            ClassModel classModel = intent.getParcelableExtra("classModel");

            // Load data into views
            textClassName.setText(classModel.getClassName());
            textClassDescription.setText(classModel.getClassDescription());
            textClassTime.setText(classModel.getClassTime());
            textAmount.setText(classModel.getAmount());
            textMeetingURL.setText(classModel.getMeetingURL());

            // Load image using Picasso
            Picasso.get().load(classModel.getImageUri()).into(imageView);
        }
    }
}
