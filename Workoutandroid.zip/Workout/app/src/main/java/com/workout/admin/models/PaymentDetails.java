package com.workout.admin.models;

public class PaymentDetails {
    private String username;
    private String email;
    private String className;
    private String classURL;

    public PaymentDetails() {
        // Default constructor required for Firestore
    }

    public PaymentDetails(String username, String email, String className, String classURL) {
        this.username = username;
        this.email = email;
        this.className = className;
        this.classURL = classURL;
    }

    // Getters and setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassURL() {
        return classURL;
    }

    public void setClassURL(String classURL) {
        this.classURL = classURL;
    }
}

