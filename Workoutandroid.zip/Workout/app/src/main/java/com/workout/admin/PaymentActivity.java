package com.workout.admin;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.workout.R;
import com.workout.admin.adapters.PaymentDetailsAdapter;
import com.workout.admin.models.PaymentDetails;

import java.util.ArrayList;
import java.util.List;

public class PaymentActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PaymentDetailsAdapter paymentDetailsAdapter;
    private List<PaymentDetails> paymentDetailsList;
    private FirebaseFirestore db;
    String classname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        recyclerView = findViewById(R.id.recycler_view_payment);
        paymentDetailsList = new ArrayList<>();
        paymentDetailsAdapter = new PaymentDetailsAdapter(this, paymentDetailsList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(paymentDetailsAdapter);

        classname =getIntent().getStringExtra("className");
        Log.d("classname", classname);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Retrieve data from Firestore
        retrievePaymentData();
    }

    private void retrievePaymentData() {
        // Access the "paid_users" collection
        db.collection("paid_users")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            // Clear previous data
                            paymentDetailsList.clear();
                            // Iterate through the documents in the collection
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                // Get the payment details from each document
                                String username = document.getString("username");
                                String email = document.getString("email");
                                String className = document.getString("classname");
                                String classUrl = document.getString("classurl");
                                // Check if the classname matches the classname passed from the previous activity
                                if (classname != null && classname.equals(className)) {
                                    // Create a PaymentDetails object and add it to the list
                                    PaymentDetails paymentDetails = new PaymentDetails(username, email, className, classUrl);
                                    paymentDetailsList.add(paymentDetails);
                                }
                            }
                            // Notify the adapter that the data set has changed
                            paymentDetailsAdapter.notifyDataSetChanged();
                        } else {
                            // Log any errors
                            Log.e("PaymentActivity", "Error getting documents: ", task.getException());
                            // Display a toast message indicating retrieval failure
                            Toast.makeText(PaymentActivity.this, "Failed to retrieve payment data", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

}
