package com.workout;
import static android.content.ContentValues.TAG;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.workout.adapter.ClassAdapter;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements PaymentResultListener {

    private String username, email; // Declare a variable to store the username and email
    private ClassAdapter classAdapter; // Reference to the ClassAdapter
    private String meetingUrlAfterPayment, classname; // Declare meetingUrlAfterPayment and classname variable
    private int backPressCount = 0;
    private long backPressTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Retrieve the username passed from LoginFragment
        username = getIntent().getStringExtra("username");
        email = getIntent().getStringExtra("useremail");

        Log.d("username",username);
        Log.d("email",email);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                if (item.getItemId() == R.id.menu_home) {
                    fragment = new ClassesFragment();
                } else if (item.getItemId() == R.id.menu_exercises) {
                    fragment = new ExercisesFragment();
                } else if (item.getItemId() == R.id.menu_messages) {
                    // Pass the username to MessagesFragment when creating its instance
                    fragment = MessagesFragment.newInstance(username);
                } else if (item.getItemId() == R.id.menu_logout){
                    showLogoutDialog();
                }

                if (fragment != null) {
                    loadFragment(fragment);
                    return true;
                }
                return false;
            }
        });

        // Set the default fragment
        loadFragment(new ClassesFragment());

        // Initialize Razorpay
        Checkout.preload(this);



    }

    // Load the fragment
    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        // Handle payment success here
        Toast.makeText(this, "Payment Successful", Toast.LENGTH_SHORT).show();

        // Check if the meeting link after payment is available
        if (meetingUrlAfterPayment != null) {
            // Inflate the custom dialog layout
            View dialogView = getLayoutInflater().inflate(R.layout.dialog_meetlink, null);

            // Initialize dialog components
            TextView meetingLinkTextView = dialogView.findViewById(R.id.meetingLinkTextView);
            Button openButton = dialogView.findViewById(R.id.openButton);
            Button cancelButton = dialogView.findViewById(R.id.cancelButton);

            // Store payment details in Firestore
            storePaymentDetailsInFirestore();

            // Set the meeting link to TextView
            meetingLinkTextView.setText(meetingUrlAfterPayment);

            // Create the dialog
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setView(dialogView);
            AlertDialog dialog = builder.create();

            // Handle click events for buttons
            openButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Open the meeting link in a browser
                    openMeetingLinkInBrowser(meetingUrlAfterPayment);
                    // Dismiss the dialog
                    dialog.dismiss();
                }
            });

            cancelButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Dismiss the dialog
                    dialog.dismiss();
                }
            });

            // Show the dialog
            dialog.show();
        } else {
            // Handle the case where meeting link is not available
            Toast.makeText(this, "Meeting URL not available", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to open the meeting link in a browser
    private void openMeetingLinkInBrowser(String meetingUrl) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(meetingUrl));
        startActivity(intent);
    }


    @Override
    public void onPaymentError(int code, String response) {
        // Handle payment failure here
        Toast.makeText(this, "Payment Failed: " + response, Toast.LENGTH_SHORT).show();
    }

    // Method to handle receiving meeting link from adapter
    public void onYesClicked(String meetingUrl, String className) {
        // Log the received meeting URL
        Log.d("MainActivity", "Meeting URL received: " + meetingUrl);
        Log.d("MainActivity", "Class name received: " + className);

        // Store the meeting URL in the class-level variable
        meetingUrlAfterPayment = meetingUrl;
        classname = className;


    }

    @Override
    public void onBackPressed() {
        // Check if there's any fragment in the back stack
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            // If no fragment in the back stack, handle app closure
            long currentTime = System.currentTimeMillis();
            if (backPressCount == 0 || currentTime - backPressTime > 2000) {
                // If it's the first back press or back press after more than 2 seconds,
                // notify the user to press back again to exit
                Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
                backPressCount = 1;
                backPressTime = currentTime;
            } else {
                // If back button is pressed again within 2 seconds, close the app
                super.onBackPressed();
            }
        }
    }

    private void showLogoutDialog() {
        // Build the confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to logout?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Perform logout action
                        logout();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Dismiss the dialog
                        dialog.dismiss();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }


    // Method to store payment details in Firestore
    private void storePaymentDetailsInFirestore() {
        // Access a Cloud Firestore instance
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Create a new user object with the payment details
        Map<String, Object> user = new HashMap<>();
        user.put("username", username);
        user.put("email", email);
        user.put("classname", classname);
        user.put("classurl", meetingUrlAfterPayment);

        // Add a new document with a generated ID
        db.collection("paid_users")
                .add(user)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.w(TAG, "Error adding document", e);
                    }
                });
    }

    private void logout() {
        // Navigate back to LoginActivity
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish(); // Finish current activity to prevent user from returning here using back button
    }
}

