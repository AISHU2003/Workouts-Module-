package com.workout;

import android.app.ProgressDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.workout.adapter.ExerciseAdapter;
import com.workout.excercisescreens.FemaleWeightGainFragment;
import com.workout.excercisescreens.FemaleWeightLossFragment;
import com.workout.excercisescreens.MaleWeightGainFragment;
import com.workout.excercisescreens.MaleWeightLossFragment;
import com.workout.model.ExerciseModel;
import com.workout.model.UserData;

import java.util.ArrayList;
import java.util.List;

public class ExercisesFragment extends Fragment {

    String username;
    EditText editTextAge, editTextHeight, editTextWeight, editTextTargetWeight;
    Spinner spinnerGender;
    Button buttonSubmit;
    FirebaseFirestore db;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_exercises, container, false);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Get username from MainActivity
        username = getActivity().getIntent().getStringExtra("username");

        // Initialize UI elements
        editTextAge = view.findViewById(R.id.editTextAge);
        editTextHeight = view.findViewById(R.id.editTextHeight);
        editTextWeight = view.findViewById(R.id.editTextWeight);
        editTextTargetWeight = view.findViewById(R.id.editTextTargetWeight);
        spinnerGender = view.findViewById(R.id.spinnerGender);
        buttonSubmit = view.findViewById(R.id.buttonSubmit);

        fetchUserDataAndRedirect();


        // Populate Spinner with gender options
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.genders_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGender.setAdapter(adapter);

        // Button click listener to save data
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserDataToFirestore();
            }
        });

        return view;
    }

    private void saveUserDataToFirestore() {
        // Get data from EditText and Spinner
        String age = editTextAge.getText().toString();
        String height = editTextHeight.getText().toString();
        String weight = editTextWeight.getText().toString();
        String targetWeight = editTextTargetWeight.getText().toString();
        String gender = spinnerGender.getSelectedItem().toString();

        // Check if weight and targetWeight are equal
        if (weight.equals(targetWeight)) {
            Toast.makeText(getContext(), "The Current Weight and Targeted Weight must not be equal", Toast.LENGTH_SHORT).show();
        } else {
            // Create a data object to be saved
            UserData userData = new UserData(age, height, weight, targetWeight, gender);

            // Add the data to Firestore under the user's document
            db.collection("users").document(username)
                    .set(userData)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(getContext(), "Data saved successfully", Toast.LENGTH_SHORT).show();
                                fetchUserDataAndRedirect();
                            } else {
                                Toast.makeText(getContext(), "Error saving data", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }




    private void fetchUserDataAndRedirect() {
        ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Fetching user data...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        db.collection("users").document(username)
                .get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        progressDialog.dismiss();
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {
                                // User document exists, fetch user data
                                UserData userData = document.toObject(UserData.class);
                                redirectBasedOnUserData(userData);
                            } else {
                                // User document doesn't exist, stay on ExercisesFragment
                                Toast.makeText(getContext(), "User data not found", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getContext(), "Error fetching user data", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void redirectBasedOnUserData(UserData userData) {
        ProgressDialog progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Redirecting...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        String gender = userData.getGender();
        double weight = Double.parseDouble(userData.getWeight());
        double targetWeight = Double.parseDouble(userData.getTargetWeight());

        Fragment fragmentToRedirect = null;

        if (gender.equals("Male")) {
            if (targetWeight < weight) {
                // Redirect to MaleWeightLossFragment
                fragmentToRedirect = new MaleWeightLossFragment();
            } else {
                // Redirect to MaleWeightGainFragment
                fragmentToRedirect = new MaleWeightGainFragment();
            }
        } else if (gender.equals("Female")) {
            if (targetWeight < weight) {
                // Redirect to FemaleWeightLossFragment
                fragmentToRedirect = new FemaleWeightLossFragment();
            } else {
                // Redirect to FemaleWeightGainFragment
                fragmentToRedirect = new FemaleWeightGainFragment();
            }
        }

        progressDialog.dismiss();

        if (fragmentToRedirect != null) {
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, fragmentToRedirect)
                    .commit();
        } else {
            // If fragmentToRedirect is null, stay on ExercisesFragment
            Toast.makeText(getContext(), "No suitable fragment found for redirection", Toast.LENGTH_SHORT).show();
        }
    }

}

