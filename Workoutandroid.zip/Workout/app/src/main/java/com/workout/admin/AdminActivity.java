package com.workout.admin;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.workout.LoginActivity;
import com.workout.R;
import com.workout.admin.fragments.ChatFragment;
import com.workout.admin.fragments.HomeFragment;
import com.workout.admin.fragments.UsersFragment;

public class AdminActivity extends AppCompatActivity {

    private String username;

    private int backPressCount = 0;
    private long backPressTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        username = "admin";

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                if (item.getItemId() == R.id.menu_home) {
                    fragment = new HomeFragment();
                }
                 else if (item.getItemId() == R.id.menu_messages) {
                    // Pass the username to MessagesFragment when creating its instance
                    fragment = ChatFragment.newInstance(username);
                }
                 else if (item.getItemId() == R.id.menu_users) {
                    fragment = new UsersFragment();
                } else if (item.getItemId() == R.id.menu_logout){
                    showLogoutDialog();
                }

                if (fragment != null) {
                    loadFragment(fragment);
                    return true;
                }
                return false;
            }
        });

        // Set the default fragment
        loadFragment(new HomeFragment());
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    @Override
    public void onBackPressed() {
        // Check if there's any fragment in the back stack
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            // If no fragment in the back stack, handle app closure
            long currentTime = System.currentTimeMillis();
            if (backPressCount == 0 || currentTime - backPressTime > 2000) {
                // If it's the first back press or back press after more than 2 seconds,
                // notify the user to press back again to exit
                Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
                backPressCount = 1;
                backPressTime = currentTime;
            } else {
                // If back button is pressed again within 2 seconds, close the app
                super.onBackPressed();
            }
        }
    }

    private void showLogoutDialog() {
        // Build the confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to logout?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Perform logout action
                        logout();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Dismiss the dialog
                        dialog.dismiss();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void logout() {
        // Navigate back to LoginActivity
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish(); // Finish current activity to prevent user from returning here using back button
    }
}
