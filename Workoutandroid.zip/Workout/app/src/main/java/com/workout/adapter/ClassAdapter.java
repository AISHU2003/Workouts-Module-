package com.workout.adapter;

import static android.content.ContentValues.TAG;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;
import com.squareup.picasso.Picasso;
import com.workout.ClassDetailActivity;
import com.workout.MainActivity;
import com.workout.R;
import com.workout.model.ClassModel;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ClassAdapter extends RecyclerView.Adapter<ClassAdapter.ViewHolder> implements PaymentResultListener {

    private List<ClassModel> classList;
    private Context context;
    private List<ViewHolder> viewHolderList; // Add this list
    private String meetingUrlAfterPayment; // Store the meeting URL temporarily

    public ClassAdapter(List<ClassModel> classList, Context context) {
        this.classList = classList;
        this.context = context;
        viewHolderList = new ArrayList<>(); // Initialize the list
        this.meetingUrlAfterPayment = null; // Initialize to null initially
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_class_with_paynow, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ClassModel classModel = classList.get(position);
        holder.textClassName.setText(classModel.getClassName());
        holder.textClassDescription.setText(classModel.getClassDescription());
        holder.textClassTime.setText(classModel.getClassTime());
        holder.textAmount.setText(classModel.getAmount());

        // Set meeting URL either from ClassModel or from temporary storage after payment
        String meetingUrl = classModel.getMeetingURL();
        if (meetingUrlAfterPayment != null && meetingUrlAfterPayment.equals(meetingUrl)) {
            holder.textMeetingURL.setText(meetingUrlAfterPayment);
        } else {
            holder.textMeetingURL.setText("Please do payment for the meeting link to be visible");
        }
        // Load image using Picasso
        Picasso.get().load(classModel.getImageUri()).into(holder.imageView);

        // Set onClickListener for Pay Now button
        holder.buttonPayNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPayNowDialog(classModel.getMeetingURL(), classModel.getAmount(), classModel.getClassName());
            }
        });
        viewHolderList.add(holder);

        // Set onClickListener for the entire item view
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the clicked class model
                ClassModel classModel = classList.get(holder.getAdapterPosition());

                // Start the ClassDetailActivity and pass the necessary data
                Intent intent = new Intent(context, ClassDetailActivity.class);
                intent.putExtra("classModel", classModel);
                context.startActivity(intent);
            }
        });
    }

    private void showPayNowDialog(String meetingURL, String amount, String className) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Do you want to pay now to view the meeting link?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        startPayment(meetingURL, amount, className);
                        // Send meeting link to MainActivity
                        ((MainActivity) context).onYesClicked(meetingURL, className);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked No, close the dialog
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void startPayment(String meetingURL, String rupees, String className) {
        // Validate the rupees string to ensure it contains only numeric characters
        if (!TextUtils.isDigitsOnly(rupees)) {
            // Show an error message or handle the invalid input appropriately
            Log.e(TAG, "Invalid amount: " + rupees);
            return;
        }
        // Convert rupees to paise
        int paise = Integer.parseInt(rupees) * 100;

        Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_6FTdwWzMrSN1Jk");

        try {
            JSONObject options = new JSONObject();
            options.put("name", "Workout Class");
            options.put("description", "Payment for workout class access");
            options.put("currency", "INR");
            options.put("amount", paise); // Amount in paise
            checkout.open((Activity) context, options);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return classList.size();
    }

    private void logMeetingUrl(int position) {
        ClassModel classModel = classList.get(position);
        String meetingUrl = classModel.getMeetingURL();
        Log.d(TAG, "Meeting URL: " + meetingUrl);
    }

    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        // Log the meeting URL after successful payment
        int currentPosition = getCurrentViewHolder().getAdapterPosition();
        if (currentPosition != RecyclerView.NO_POSITION) {
            logMeetingUrl(currentPosition);
        } else {
            Log.e(TAG, "Invalid position: " + currentPosition);
        }
        notifyDataSetChanged(); // Update the UI
    }

    public void setMeetingLinkAfterPayment(String meetingUrlAfterPayment) {
        this.meetingUrlAfterPayment = meetingUrlAfterPayment;
        notifyDataSetChanged();
    }

    private ViewHolder getCurrentViewHolder() {
        for (ViewHolder viewHolder : viewHolderList) {
            if (viewHolder.getAdapterPosition() != RecyclerView.NO_POSITION) {
                return viewHolder;
            }
        }
        return null;
    }

    @Override
    public void onPaymentError(int code, String response) {
        Toast.makeText(context, "Payment Failed: " + response, Toast.LENGTH_LONG).show();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView textClassName;
        public TextView textClassDescription;
        public TextView textClassTime;
        public TextView textAmount;
        public TextView textMeetingURL;
        public ImageView imageView;
        public Button buttonPayNow;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textClassName = itemView.findViewById(R.id.textClassName);
            textClassDescription = itemView.findViewById(R.id.textClassDescription);
            textClassTime = itemView.findViewById(R.id.textClassTime);
            textAmount = itemView.findViewById(R.id.textAmount);
            textMeetingURL = itemView.findViewById(R.id.textMeetingURL);
            imageView = itemView.findViewById(R.id.imageView);
            buttonPayNow = itemView.findViewById(R.id.buttonPayNow);
        }
    }
}
