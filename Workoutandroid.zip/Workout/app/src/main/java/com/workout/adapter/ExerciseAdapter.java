package com.workout.adapter;

import android.app.Dialog;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.workout.R;
import com.workout.model.Exercise;

import java.util.List;

public class ExerciseAdapter extends RecyclerView.Adapter<ExerciseAdapter.ExerciseViewHolder> {

    private List<Exercise> exerciseList;

    public ExerciseAdapter(List<Exercise> exerciseList) {
        this.exerciseList = exerciseList;
    }
    private OnItemClickListener onItemClickListener;


    @NonNull
    @Override
    public ExerciseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.exercise_item, parent, false);
        return new ExerciseViewHolder(itemView);
    }

    // Interface for click listener
    public interface OnItemClickListener {
        void onItemClick(Exercise exercise);
    }


    @Override
    public void onBindViewHolder(@NonNull ExerciseViewHolder holder, int position) {
        Exercise exercise = exerciseList.get(position);
        holder.bind(exercise);

        // Set click listener for each item
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(exercise);
                }
            }
        });
    }

    // Method to set the click listener
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }
    @Override
    public int getItemCount() {
        return exerciseList.size();
    }

    static class ExerciseViewHolder extends RecyclerView.ViewHolder {

        private TextView exerciseNameTextView;
        private TextView descriptionTextView;
        private pl.droidsonroids.gif.GifImageView gifImageView;
        private Button startButton;

        ExerciseViewHolder(@NonNull View itemView) {
            super(itemView);
            exerciseNameTextView = itemView.findViewById(R.id.textviewExcerciseName);
            descriptionTextView = itemView.findViewById(R.id.textviewdescription);
            gifImageView = itemView.findViewById(R.id.gifimage);
            startButton = itemView.findViewById(R.id.buttonStart);
        }

        void bind(Exercise exercise) {
            exerciseNameTextView.setText(exercise.getName());

            // Set description points line by line
            StringBuilder description = new StringBuilder();
            for (String point : exercise.getDescriptionPoints()) {
                description.append(point).append("\n"); // Append each point followed by a new line
            }
            descriptionTextView.setText(description.toString());

            gifImageView.setImageResource(exercise.getGifResource()); // Set GIF here

            // Declare secondsLeft as final
            final int secondsLeft = 30;

            startButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Show the timer dialog
                    showDialog(secondsLeft);
                }
            });
        }


        private void showDialog(final int initialSeconds) {
            // Create a dialog
            Dialog dialog = new Dialog(itemView.getContext());
            dialog.setContentView(R.layout.dialog_timer);
            dialog.setCancelable(false); // Prevent dialog from being dismissed by tapping outside

            // Adjust dialog dimensions based on screen size
            ViewGroup.LayoutParams params = dialog.getWindow().getAttributes();
            params.width = ViewGroup.LayoutParams.MATCH_PARENT;
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setAttributes((android.view.WindowManager.LayoutParams) params);

            // Initialize views
            TextView timerTextView = dialog.findViewById(R.id.timerTextView);
            Button playButton = dialog.findViewById(R.id.playButton);
            Button pauseButton = dialog.findViewById(R.id.pauseButton);
//            Button resumeButton = dialog.findViewById(R.id.ResumeButton); // Added Resume button
            Button resetButton = dialog.findViewById(R.id.resetButton);
            Button closeButton = dialog.findViewById(R.id.closeButton);

            // Set initial timer value
            timerTextView.setText(String.valueOf(initialSeconds));

            // Initialize the remaining time variable
            long[] remainingTime = {initialSeconds * 1000};
            CountDownTimer[] timer = {createTimer(remainingTime[0], timerTextView)};
            boolean[] isTimerRunning = {false}; // Track if the timer is running

            // Play button click listener
            playButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Start or resume the timer
                    if (!isTimerRunning[0]) {
                        timer[0] = createTimer(remainingTime[0], timerTextView);
                        timer[0].start();
                        isTimerRunning[0] = true;
                    }
                }
            });

            // Pause/Resume button click listener
            pauseButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isTimerRunning[0]) {
                        // Pause the timer and store the remaining time
                        timer[0].cancel();
                        isTimerRunning[0] = false;
                        remainingTime[0] = Long.parseLong(timerTextView.getText().toString()) * 1000; // Update remaining time
                    } else {
                        // Resume the timer
                        timer[0] = createTimer(remainingTime[0], timerTextView);
                        timer[0].start();
                        isTimerRunning[0] = true;
                    }
                }
            });


//            // Resume button click listener
//            resumeButton.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (!isTimerRunning[0]) {
//                        // Resume the timer
//                        timer[0] = createTimer(remainingTime[0], timerTextView);
//                        timer[0].start();
//                        isTimerRunning[0] = true;
//                    }
//                }
//            });

            // Reset button click listener
            resetButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Reset the timer and set it to initial value
                    remainingTime[0] = initialSeconds * 1000;
                    timerTextView.setText(String.valueOf(initialSeconds));
                    // Restart the timer
                    timer[0].cancel();
                    timer[0] = createTimer(remainingTime[0], timerTextView);
                    isTimerRunning[0] = false;
                }
            });

            // Close button click listener
            closeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Dismiss the dialog
                    dialog.dismiss();
                }
            });

            // Show the dialog
            dialog.show();
        }


        // Create CountDownTimer
        private CountDownTimer createTimer(long remainingTime, TextView timerTextView) {
            return new CountDownTimer(remainingTime, 1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    // Update timer text
                    timerTextView.setText(String.valueOf(millisUntilFinished / 1000));
                }

                @Override
                public void onFinish() {
                    // Timer finished, handle accordingly
                    timerTextView.setText("Finished");
                }
            };
        }

    }
}
