package com.workout.admin.fragments;



import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.workout.R;
import com.workout.admin.AddClassActivity;
import com.workout.admin.adapters.ClassAdapter;
import com.workout.admin.models.ClassModel;


import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private List<ClassModel> classList;
    private ClassAdapter classAdapter;
    private RecyclerView recyclerView;
    private FloatingActionButton fabAddClass;
    private FirebaseFirestore db;
    private CollectionReference classesRef;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = FirebaseFirestore.getInstance();
        classesRef = db.collection("classes");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize RecyclerView and adapter
        recyclerView = view.findViewById(R.id.recyclerView);
        classList = new ArrayList<>();
        classAdapter = new ClassAdapter(classList,FirebaseFirestore.getInstance());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(classAdapter);

        // Find the Floating Action Button
        fabAddClass = view.findViewById(R.id.fab_add_class);

        // Set click listener for the FAB
        fabAddClass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddClassActivity
                startActivity(new Intent(getActivity(), AddClassActivity.class));
            }
        });

        // Load classes data
        loadClasses();

        return view;
    }

    private void loadClasses() {
        Query query = db.collection("classes").orderBy("className", Query.Direction.ASCENDING);

        query.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot querySnapshot, @Nullable FirebaseFirestoreException e) {
                if (e != null) {
                    // Handle error
                    return;
                }

                classList.clear();
                for (DocumentSnapshot document : querySnapshot.getDocuments()) {
                    ClassModel classModel = document.toObject(ClassModel.class);
                    classList.add(classModel);
                }
                classAdapter.notifyDataSetChanged();
            }
        });
    }


}
