package com.workout.admin.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.workout.R;
import com.workout.admin.models.PaymentDetails;

import java.util.List;

public class PaymentDetailsAdapter extends RecyclerView.Adapter<PaymentDetailsAdapter.ViewHolder> {
    private List<PaymentDetails> paymentDetailsList;
    private Context context;

    public PaymentDetailsAdapter(Context context, List<PaymentDetails> paymentDetailsList) {
        this.context = context;
        this.paymentDetailsList = paymentDetailsList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.payment_details_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        PaymentDetails paymentDetails = paymentDetailsList.get(position);
        holder.bind(paymentDetails);
    }

    @Override
    public int getItemCount() {
        return paymentDetailsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView usernameTextView;
        private TextView emailTextView;
        private TextView classNameTextView;
        private TextView classUrlTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            usernameTextView = itemView.findViewById(R.id.textViewUsername);
            emailTextView = itemView.findViewById(R.id.textViewEmail);
            classNameTextView = itemView.findViewById(R.id.textViewClassName);
            classUrlTextView = itemView.findViewById(R.id.textViewClassURL);
        }

        public void bind(PaymentDetails paymentDetails) {
            usernameTextView.setText(paymentDetails.getUsername());
            emailTextView.setText(paymentDetails.getEmail());
            classNameTextView.setText(paymentDetails.getClassName());
            classUrlTextView.setText(paymentDetails.getClassURL());
        }
    }
}

